-- Use the `ref` function to select from other models

select *
from "KEBOOLA_9457"."WORKSPACE_26035590"."stg_model"
where "id" = 1